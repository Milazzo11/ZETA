"""
API module.

:author: Max Milazzo
"""