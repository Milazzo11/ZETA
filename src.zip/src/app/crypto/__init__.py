"""
Cryptography library module.

:author: Max Milazzo
"""