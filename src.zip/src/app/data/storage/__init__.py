"""
Database storage module.

:author: Max Milazzo
"""