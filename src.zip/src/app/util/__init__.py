"""
Utility module.

:author: Max Milazzo
"""