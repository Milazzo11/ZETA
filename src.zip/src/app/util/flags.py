"""
"""



demo = False
# injected flag for "demo mode" (Redis and database connection pool will not initialize)
# (do not modify)